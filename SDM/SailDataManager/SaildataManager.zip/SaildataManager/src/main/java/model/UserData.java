package model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "userData")
public class UserData {
    @Id
    private String id;

    private String userId;

    private String timestamp;

    private double accX;

    private double accY;

    private double accZ;

    private double light;

    private double temp;

    public UserData(String id, String userId, String timestamp, double accX, double accY, double accZ, double light, double temp) {
        this.id = id;
        this.userId = userId;
        this.timestamp = timestamp;
        this.accX = accX;
        this.accY = accY;
        this.accZ = accZ;
        this.light = light;
        this.temp = temp;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public double getAccX() {
        return accX;
    }

    public void setAccX(double accX) {
        this.accX = accX;
    }

    public double getAccY() {
        return accY;
    }

    public void setAccY(double accY) {
        this.accY = accY;
    }

    public double getAccZ() {
        return accZ;
    }

    public void setAccZ(double accZ) {
        this.accZ = accZ;
    }

    public double getLight() {
        return light;
    }

    public void setLight(double light) {
        this.light = light;
    }

    public double getTemp() {
        return temp;
    }

    public void setTemp(double temp) {
        this.temp = temp;
    }

    @Override
    public String toString() {
        return "model.UserData{" +
                "id=" + id +
                ", userId='" + userId + '\'' +
                ", timestamp=" + timestamp +
                ", accX=" + accX +
                ", accY=" + accY +
                ", accZ=" + accZ +
                ", light=" + light +
                ", temp=" + temp +
                '}';
    }
}

