package config;

import com.mongodb.Mongo;
import com.mongodb.MongoClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.authentication.UserCredentials;
import org.springframework.data.mongodb.MongoDbFactory;
import org.springframework.data.mongodb.config.AbstractMongoConfiguration;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.SimpleMongoDbFactory;
@Configuration
@ComponentScan(basePackages = "onlab.iot.datasailmanager.backend")
public class ApplicationConfig extends AbstractMongoConfiguration {
    @Override
    protected String getDatabaseName() {
        return "iotDB";
    }

    @Override
    public Mongo mongo() throws Exception {
        return new MongoClient("127.0.0.1",27017);
    }

    @Bean
    public MongoDbFactory mongoDbFactory() throws Exception {
        UserCredentials userCredentials = new UserCredentials("", "");
        return new SimpleMongoDbFactory(mongo(), getDatabaseName(), userCredentials);
    }

    @Bean
    public MongoTemplate mongoTemplate() throws Exception {
        MongoTemplate mongoTemplate = new MongoTemplate(mongoDbFactory());
        return mongoTemplate;
    }
}
