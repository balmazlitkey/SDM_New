import config.ApplicationConfig;
import model.UserData;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import service.UserDataService;

import java.util.List;

public class App {

    public static void main(String args[]) {

        AbstractApplicationContext context = new AnnotationConfigApplicationContext(ApplicationConfig.class);
        UserDataService userDataService = (UserDataService) context.getBean("userDataService");
        // Delete All cars
        userDataService.deleteAll();

        UserData userData=new UserData("1","1","30",0.2,0.2,0.2,0.2,0.2);
        userDataService.create(userData);
        UserData userData2=new UserData("2","1","30",0.2,0.2,0.2,0.2,0.2);
        userDataService.create(userData);
        UserData userData3=new UserData("3","1","30",0.2,0.2,0.2,0.2,0.2);
        userDataService.create(userData);



        System.out.println("Find One:- " + userDataService.find(userData));

        System.out.println("Find All!!");

        List< UserData > userDataList = userDataService.findAll();
        for (UserData userData11: userDataList) {
            System.out.println(userData11);
        }
        System.out.println();
        userDataService.delete(userData2);

        System.out.println();
        userData3.setLight(6.6969696969);
        userDataService.update(userData3);

        System.out.println("Find All After Update!!");

        userDataList = userDataService.findAll();
        for (UserData userData11: userDataList){
            System.out.println(userData11);
        }

        context.close();
    }
}
