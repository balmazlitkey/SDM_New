package DAO;

import model.UserData;

import java.util.List;

public interface UserDataDAO {
    public void create(UserData userData);

    public void update(UserData userData);

    public void delete(UserData userData);

    public void deleteAll();

    public UserData find(UserData userData);

    public List< UserData > findAll();
}
