package DAO;

import model.UserData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
@Qualifier("DAO.UserDataDAO")
public class UserDataDAOImpl implements UserDataDAO {

    @Autowired
   private MongoTemplate mongoTemplate;

   private final String COLLECTION = "userDatas";

    @Override
    public void create(UserData userData) {
        mongoTemplate.insert(userData);

    }

    @Override
    public void update(UserData userData) {
        mongoTemplate.save(userData);

    }

    @Override
    public void delete(UserData userData) {
        mongoTemplate.remove(userData);

    }

    @Override
    public void deleteAll() {
        mongoTemplate.remove(new Query(), COLLECTION);

    }

    @Override
    public UserData find(UserData userData) {
        Query query = new Query(Criteria.where("_id").is(userData.getId()));
        return mongoTemplate.findOne(query, UserData.class, COLLECTION);
    }

    @Override
    public List<UserData> findAll() {
        return (List < UserData > ) mongoTemplate.findAll(UserData.class);
    }
}
