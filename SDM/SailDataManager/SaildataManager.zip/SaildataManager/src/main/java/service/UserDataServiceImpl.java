package service;

import DAO.UserDataDAO;
import model.UserData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service("userDataService")
public class UserDataServiceImpl implements UserDataService {

    @Autowired
    UserDataDAO userDataDao;
    @Override
    public void create(UserData userData) {
        userDataDao.create(userData);
    }

    @Override
    public void update(UserData userData) {
        userDataDao.update(userData);
    }

    @Override
    public void delete(UserData userData) {
        userDataDao.delete(userData);
    }

    @Override
    public void deleteAll() {
        userDataDao.deleteAll();
    }

    @Override
    public UserData find(UserData userData) {
       return userDataDao.find(userData);
    }

    @Override
    public List<UserData> findAll() {
        return  userDataDao.findAll();
    }
}
