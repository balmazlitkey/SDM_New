package service;

import model.UserData;

import java.util.List;

public interface UserDataService {

    public void create(UserData car);

    public void update(UserData car);

    public void delete(UserData car);

    public void deleteAll();

    public UserData find(UserData car);

    public List< UserData > findAll();
}
